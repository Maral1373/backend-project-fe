const Books = () => {
  return <h1>Books page</h1>;
};

export default Books;
